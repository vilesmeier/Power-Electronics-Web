/********************************************************************
* File: main.c                                                      *
*                                                                   *
* Platform: Intel 80x86                                             *
*                                                                   *
* Description: Reads bytes from a binary input file, packs them     *
* into 2-byte words assuming little endian format, and writes the   *
* words to an ASCII output file.                                    *
*                                                                   *
* Author: David M. Alter, Texas Instruments Inc.                    *
*                                                                   *
* History:                                                          *
*    April 3, 2006 - Original (D. Alter)                            *
*                                                                   *
********************************************************************/

#include "stdio.h"

void main(void)
{
	char str[64];
	unsigned char LoByte, HiByte, GotByte;
	unsigned short Word;
	FILE *InFile=NULL, *OutFile=NULL;

// Get the binary input filename and open it
	while(InFile == NULL)
	{
		printf("\nEnter the binary input filename: ");
		scanf("%s", str);
		InFile = fopen(str,"rb");
		if(InFile == NULL) printf("ERROR - Cannot open file\n\n");
	}

// Get the output filename and open it
	while(OutFile == NULL)
	{
		printf("\nEnter the ASCII output filename: ");
		scanf("%s", str);
		OutFile = fopen(str,"w");
		if(OutFile == NULL) printf("ERROR - Cannot open file\n\n");
	}

// Do the byte packing
	while(1)
	{
		GotByte = fread(&LoByte, 1, 1, InFile);		// Read the lo byte
		if(!GotByte) break; 						// Exit loop if we didn't get a byte (e.g., end of file)

		GotByte = fread(&HiByte, 1, 1, InFile);		// Read the hi byte
		if(!GotByte)								// Check that we got a byte
		{
			fprintf(OutFile, "0x%.4x,\n", LoByte);	// Write the last lo byte
			break;									// Exit the loop
		}

		Word = (HiByte << 8) | LoByte;				// Form the byte-packed word
		fprintf(OutFile, "0x%.4x,\n", Word);		// Write the word to the output file
	}

// Finish up
	fclose(InFile);									// Close the file
	fclose(OutFile);								// Close the file
	printf("\nByte packing complete");

} // end main()

//************ End of File *****************


