D. Alter      May 22, 2006

Byte2Word is a console program built using Microsoft Visual C++ v5.0.

It parses a binary file, and creates an ASCII file containing the binary data
packed into 16-bit words.

It consists of the following files:

  Byte2Word.dsw -- Visual C++ workspace file
  Byte2Word.dsp -- Visual C++ project file
  Byte2Word.opt -- Visual C++ workspace options file
  main.c        -- source file
  readme.txt    -- this text file
