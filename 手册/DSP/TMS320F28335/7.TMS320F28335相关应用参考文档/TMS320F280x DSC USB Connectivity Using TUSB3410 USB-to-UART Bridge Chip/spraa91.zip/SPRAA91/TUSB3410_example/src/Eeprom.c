/**********************************************************************
* File: EEPROM.c
* Devices: TMS320F2808, TMS320F2806, TMS320F2801
* Author: David M. Alter, Texas Instruments Inc.
* History:
*   01/13/06 - original (D. Alter)
**********************************************************************/

#include "DSP280x_Device.h"				// Peripheral address definitions
#include "TUSB3410_nonBIOS.h"			// Main include file for this project

/**********************************************************************
* Function: ReadEeprom()
* Description: Gets a byte of data from byte-packed memory
* Function Prototype: Uint16 ReadEeprom(Uint16*, Uint16);
* Useage: Data = ReadEeprom(BaseAddr, ByteOffset);
* Input Parameters:
*    BaseAddr = Pointer to 1st word in memory of EEPROM area
*    ByteOffset = Byte offset from base address
* Return Value:
*    Data = the byte data value
* Notes: None
**********************************************************************/
Uint16 ReadEeprom(Uint16* BaseAddr, Uint16 ByteOffset)
{
const Uint16* DataPtr;										// Pointer to EEPROM data

	DataPtr = BaseAddr + (ByteOffset >> 1);					// Setup the pointer to the EEPROM data

	return(*DataPtr >> ((ByteOffset & 0x1) << 3)) & 0xFF;	// Return the unpacked byte

} // end ReadEeprom()
