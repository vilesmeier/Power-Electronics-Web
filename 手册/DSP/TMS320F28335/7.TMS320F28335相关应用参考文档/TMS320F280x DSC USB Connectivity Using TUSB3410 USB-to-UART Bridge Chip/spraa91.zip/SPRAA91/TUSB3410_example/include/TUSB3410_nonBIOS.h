/**********************************************************************
* File: TUSB3410_nonBIOS.h
* Device: TMS320F2808
* Author: David M. Alter, Texas Instruments Inc.
* Description: Include file for example non-BIOS project.  Include this
*   file in all C-source files.
* History:
*   10/26/04 - original (D. Alter)
**********************************************************************/

#ifndef EXAMPLE_H
#define EXAMPLE_H


//---------------------------------------------------------------------------
// User Selectable Values
//

// SCI Baud Rate.
//  BRR = (LSPCLK)/[(baudrate)*8] - 1
//
#define BRR_9600		1300u					// 9600 baud when LSPCLK = 100MHz
#define BRR_115200		108u					// 115200 baud when LSPCLK = 100MHz
#define BRR_460800		26u						// 460800 baud when LSPCLK = 100MHz
#define BRR				BRR_460800				// User should select desired baudrate from the above


//---------------------------------------------------------------------------
// Include Standard C Language Header Files
//
#include <string.h>


//---------------------------------------------------------------------------
// Include any other Header Files
//
#include "DSP280x_DefaultIsr.h"            // ISR definitions (for non-BIOS projects only)


//---------------------------------------------------------------------------
// Function Prototypes
//
extern Uint16 ReadEeprom(Uint16* BaseAddr, Uint16 ByteOffset);
extern void	  InitSysCtrl(void);
extern void   InitPieCtrl(void);
extern void   InitGpio(void);
extern void   InitFlash(void);
extern void   InitSciA(Uint16);
extern void   InitI2cA(void);
extern void   SetDBGIER(Uint16);

//---------------------------------------------------------------------------
// Global symbols defined in the linker command file
//
extern Uint16 secureRamFuncs_loadstart;
extern Uint16 secureRamFuncs_loadend;
extern Uint16 secureRamFuncs_runstart;


//---------------------------------------------------------------------------
// Global symbols defined in source files
//
extern const struct PIE_VECT_TABLE PieVectTableInit;
extern const Uint16 TUSB3410BootData[];

//---------------------------------------------------------------------------
#endif  // end of EXAMPLE_H definition

/*** end of file *****************************************************/
