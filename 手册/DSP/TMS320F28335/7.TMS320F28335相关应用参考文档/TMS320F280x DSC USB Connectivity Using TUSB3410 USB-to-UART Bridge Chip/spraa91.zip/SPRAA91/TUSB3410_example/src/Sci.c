/**********************************************************************
* File: Sci.c
* Devices: TMS320F2808, TMS320F2806, TMS320F2801
* Author: David M. Alter, Texas Instruments Inc.
* History:
*   05/31/05 - original (D. Alter)
**********************************************************************/

#include "DSP280x_Device.h"				// Peripheral address definitions
#include "TUSB3410_nonBIOS.h"			// Main include file for this project


/**********************************************************************
* Function: InitSciA()
* Description: Initializes SciA on the F280x.
* Function Prototype: void InitSciA(Uint16);
* Useage: InitSciA(Baud);
* Input Parameters:
*    Baud = 16-bit value to be put in SCIHBAUD:SCILBAUD registers
* Return Value: None
* Notes: None
**********************************************************************/
void InitSciA(Uint16 Baud)
{
//*** Disable the SCI
	SciaRegs.SCICTL1.all = 0x0000;				// Disable TX and RX, SW RESET asserted

//*** Configure shared pins
	asm(" EALLOW");								// Enable EALLOW protected register access
	GpioCtrlRegs.GPAMUX2.bit.GPIO28 = 1;		// 0=GPIO, 1=SCIRXDA   2=rsvd       3=TZ5
	GpioCtrlRegs.GPAMUX2.bit.GPIO29 = 1;		// 0=GPIO, 1=SCITXDA   2=rsvd       3=TZ6
	asm(" EDIS");								// Disable EALLOW protected register access

//*** Initialize the SCI
   SciaRegs.SCICCR.all =0x0007;
// bit 15-8      0's:    reserved
// bit 7         0:      STOP BITS, 0=one stop bit, 1=two stop bits
// bit 6         0:      EVEN/ODD PARITY, 0=odd, 1=even
// bit 5         0:      PARITY ENABLE, 0=disabled, 1=enabled
// bit 4         0:      LOOPBACK ENA, 0=disabled, 1=enabled
// bit 3         0:      ADDR/IDLE MODE, 0=idle-line, 1=address-bit
// bit 2-0       111:    SCICHARx, 111b = 8 bits in a character

	SciaRegs.SCILBAUD = Baud;					// Lower byte of baud rate
	SciaRegs.SCIHBAUD = Baud >> 8;				// Upper byte of baud rate

	SciaRegs.SCICTL2.all = 0x0003;
// bit 15-8      0's:    reserved
// bit 7         0:      TXRDY, read-only
// bit 6         0:      TX EMPTY, read-only
// bit 5-2       0's:    reserved
// bit 1         1:      RX/BK INT ENA, 0=disabled, 1=enabled
// bit 0         1:      TX INT ENA, 0=disabled, 1=enabled

	SciaRegs.SCIFFTX.bit.SCIFFENA = 0;			// FIFOs disabled

	PieCtrlRegs.PIEIER9.bit.INTx1 = 1;			// Enable SCIRXINTA in the PIE
	PieCtrlRegs.PIEIER9.bit.INTx2 = 1;			// Enable SCITXINTA in the PIE
	IER |= 0x0100;								// Enable INT9 in the core

	SciaRegs.SCICTL1.all = 0x0023;				// enable the SCI
// bit 15-7      0's:    reserved
// bit 6         0:      RX ERR INT ENA, 0=disabled, 1=enabled
// bit 5         1:      SW RESET, 0=reset, 1=normal operation
// bit 4         0:      reserved
// bit 3         0:      TXWAKE, 0=feature not enabled
// bit 2         0:      SLEEP, 0=disabled, 1=enabled
// bit 1         1:      TXENA, 0=disabled, 1=enabled
// bit 0         1:      RXENA, 0=disabled, 1=enabled


} // end InitSciA()


/*** end of file *****************************************************/
