David M. Alter
Texas Instruments, Inc.
May 26, 2006
----------------------------------

This code accompanies the Texas Instruments application report "TMS320F280x Digital
Signal Controller USB Connectivity using the TUSB3410 USB-to-UART Bridge Chip,"  TI
literature #SPRAA91.

The application report can be downloaded from the TI website at http://www.ti.com.

Please read and understand the disclaimer contained in the file disclaimer.txt.

------------ END OF FILE -------------------
