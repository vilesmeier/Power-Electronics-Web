/**********************************************************************
* File: main_nonBIOS.c
* Description:
* Devices: TMS320F2808, TMS320F2806, TMS320F2801
* Author: David M. Alter, Texas Instruments Inc.
* History:
*   01/09/06 - original (D. Alter)
**********************************************************************/

#include "DSP280x_Device.h"				// Peripheral address definitions
#include "TUSB3410_nonBIOS.h"			// Main include file for this project

//*** Create a global array that contains the bootload data for the TUSB3410
#pragma DATA_SECTION(TUSB3410BootData, "TUSB3410_Boot_Mem");
const Uint16 TUSB3410BootData[] = {
									#include "VCP-3410-FW_in_EEPROM_packed.h"
								  };

//*********************************************************************
// Function: main()
//
// Description: Main function
//*********************************************************************
void main(void)
{

//*** CPU Initialization
	InitSysCtrl();						// Initialize the CPU (FILE: SysCtrl.c)
	InitGpio();							// Initialize the shared GPIO pins (FILE: Gpio.c)
	InitPieCtrl();						// Initialize and enable the PIE (FILE: PieCtrl.c)

//*** Copy all FLASH sections that need to run from RAM (use memcpy() from RTS library)

	// Section secureRamFuncs contains user defined code that runs from CSM secured RAM
	memcpy(	&secureRamFuncs_runstart,
			&secureRamFuncs_loadstart,
			&secureRamFuncs_loadend - &secureRamFuncs_loadstart);

//*** Initialize the FLASH
	InitFlash();						// Initialize the FLASH (FILE: SysCtrl.c)

//*** Peripheral Initialization
	InitSciA(BRR);						// Initialize SCI-A
	InitI2cA();							// Initialize the I2C port

//*** Enable interrupts
    SetDBGIER(IER);						// Configure the DBGIER for realtime debug
	asm(" CLRC INTM, DBGM");			// Enable global interrupts and realtime debug

//*** Release the TUSB3410 from reset.
	GpioDataRegs.GPASET.bit.GPIO0 = 1;	// Drive RESET\ pin high on TUSB3410

//*** Main Loop
	while(1)							// Dummy loop.  Wait for an interrupt.
	{
		asm(" NOP");
	}

} //end of main()


/*** end of file *****************************************************/
