/**********************************************************************
* File: I2c.c
* Devices: TMS320F2808, TMS320F2806, TMS320F2801
* Author: David M. Alter, Texas Instruments Inc.
* History:
*   05/31/05 - original (D. Alter)
**********************************************************************/

#include "DSP280x_Device.h"				// Peripheral address definitions
#include "TUSB3410_nonBIOS.h"			// Main include file for this project


/**********************************************************************
* Function: InitI2cA()
* Description: Initializes I2cA on the F280x to bootload the TUSB3410.
* Function Prototype: void InitI2cA(void);
* Useage: InitI2cA(void);
* Input Parameters: None
* Return Value: None
* Notes: None
**********************************************************************/
void InitI2cA(void)
{
//*** Disable the I2C
	I2caRegs.I2CMDR.all = 0x0000;				// I2C module is disable

//*** Configure shared pins
	asm(" EALLOW");								// Enable EALLOW protected register access
	GpioCtrlRegs.GPBMUX1.bit.GPIO32 = 1;		// 0=GPIO, 1=SDAA      2=EPWMSYNCI  3=ADCSOCAO
	GpioCtrlRegs.GPBMUX1.bit.GPIO33 = 1;		// 0=GPIO, 1=SCLA      2=EPWMSYNCO  3=ADCSOCBO
	asm(" EDIS");								// Disable EALLOW protected register access

//*** Initialize the I2C -- Make it look like a Type III EEPROM
	I2caRegs.I2COAR = 0x0050;					// TUSB3410 expects Type III EEPROM I2C address of 0x50
	I2caRegs.I2CIER.bit.RRDY = 1;				// Enable receive interrupt
	I2caRegs.I2CIER.bit.SCD = 1;				// Enable stop condition interrupt.

	PieCtrlRegs.PIEIER8.bit.INTx1 = 1;			// Enable I2CINT1A in PIE group 8
	IER |= 0x0080;								// Enable INT8 in IER to enable PIE group

	I2caRegs.I2CFFTX.bit.I2CFFEN = 0;			// I2C FIFOs disabled

	I2caRegs.I2CMDR.all = 0x6020;
// bit 15        0:      NACKMOD, 0 = send ACK each acknowlege cycle
// bit 14        1:      FREE, 1 = ignor emulation halt, 0 = stop on emulation halt
// bit 13        0:      STT, not applicable in slave mode
// bit 12        0:      reserved
// bit 11        0:      STP, not applicable in slave mode
// bit 10        0:      MST, 0 = slave mode, 1 = master mode
// bit 9         0:      TRX, don't care when MST=0, FDF=0
// bit 8         0:      XA, 0 = 7-bit address mode, 1 = 10-bit address mode
// bit 7         0:      RM, not applicable in slave mode
// bit 6         0:      DLB, 0 = digital loopback disabled
// bit 5         1:      IRS: 0 = I2C module reset, 1 = I2C module enabled
// bit 4         0:      STB, not applicable in slave mode
// bit 3         0:      FDF, 0 = free data format disabled (use 7-/10-bit addressing)
// bit 2-0       000:    BC, 000b = 8 bits per data byte

} // end InitI2cA()


/*** end of file *****************************************************/
