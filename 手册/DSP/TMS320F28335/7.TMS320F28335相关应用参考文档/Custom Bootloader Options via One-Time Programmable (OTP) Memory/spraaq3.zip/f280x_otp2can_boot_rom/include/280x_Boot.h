// TI File $Revision: /main/2 $
// Checkin $Date: January 10, 2005   14:45:35 $
//###########################################################################
//
// FILE:   F280x_Boot.h
//
// TITLE:  F280x Boot ROM Definitions.
//
//###########################################################################
// $TI Release:$
// $Release Date:$
//###########################################################################

#ifndef F280X_BOOT_H
#define F280X_BOOT_H

//---------------------------------------------------------------------------
// Fixed boot entry points:
// 
#define FLASH_ENTRY_POINT 0x3F7FF6
#define OTP_ENTRY_POINT   0x3D7800
#define RAM_ENTRY_POINT   0x000000
#define PASSWORD_LOCATION 0x3F7FF8


#define ERROR                   1
#define NO_ERROR                0
#define EIGHT_BIT               8
#define SIXTEEN_BIT            16
#define EIGHT_BIT_HEADER   0x08AA
#define SIXTEEN_BIT_HEADER 0x10AA

typedef Uint16 (* uint16fptr)();
extern uint16fptr GetWordData;

#endif  // end of F280x_BOOT_H definition
