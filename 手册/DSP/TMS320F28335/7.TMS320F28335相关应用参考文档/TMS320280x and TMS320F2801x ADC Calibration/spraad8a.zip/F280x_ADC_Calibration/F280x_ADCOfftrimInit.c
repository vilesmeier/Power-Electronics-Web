//###########################################################################
//
// FILE:	ADCOfftrimInit.c
//
// TITLE:	Set OFFTRIM register for ADC Calibration Driver Program.
//
//###########################################################################
//
// Ver  | dd-mmm-yyyy |  Who  | Description of changes
// =====|=============|=======|==============================================
//  1.0 | 07 Feb 2006 |  MP   | Original Release.
//
//###########################################################################
//
//Assumptions: Assume channel selected is connected to ADCLO(Analog Ground)
//###########################################################################

#include "DSP280x_Device.h"
#define ARTOFF 10  // Make Offset artifically +10LSBs to ensure accurate 0V detection
Uint16 ADC_READ[32];
Uint16 i = 0;
int Sum = 0;

void ADCOfftrimInit(void)
{
	Sum = 0;
	AdcRegs.ADCTRL3.bit.SMODE_SEL = 0;  //set up for Sequential Sampling Mode
	AdcRegs.ADCTRL1.bit.SEQ_CASC = 0;
	AdcRegs.ADCMAXCONV.bit.MAX_CONV1 = 7;
	AdcRegs.ADCCHSELSEQ1.all = 0x7777;	//set to channel converting ADCLO
    AdcRegs.ADCCHSELSEQ2.all = 0x7777;  //set to channel converting ADCLO
    
    AdcRegs.ADCTRL2.bit.RST_SEQ1 = 1;
    AdcRegs.ADCOFFTRIM.bit.OFFSET_TRIM = 80;  //set offset trim to detect offset of +/-60LSBs
       
    
    	
    	AdcRegs.ADCTRL2.bit.SOC_SEQ1 = 1;
    	while(AdcRegs.ADCST.bit.INT_SEQ1 == 0){}
    	
    		
    		Sum+= AdcMirror.ADCRESULT0;
    		Sum+= AdcMirror.ADCRESULT1;
    		Sum+= AdcMirror.ADCRESULT2;
    		Sum+= AdcMirror.ADCRESULT3;
    		Sum+= AdcMirror.ADCRESULT4;
    		Sum+= AdcMirror.ADCRESULT5;
    		Sum+= AdcMirror.ADCRESULT6;
    		Sum+= AdcMirror.ADCRESULT7;
    	
    	AdcRegs.ADCST.bit.INT_SEQ1_CLR = 1;
    	
    	
    					
		AdcRegs.ADCOFFTRIM.bit.OFFSET_TRIM = (AdcRegs.ADCOFFTRIM.bit.OFFSET_TRIM - (Sum/8))+ARTOFF;		    
        


// No more.
}


