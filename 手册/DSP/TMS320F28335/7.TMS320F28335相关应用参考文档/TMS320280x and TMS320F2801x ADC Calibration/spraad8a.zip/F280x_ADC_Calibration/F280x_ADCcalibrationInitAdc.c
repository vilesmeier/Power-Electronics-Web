//###########################################################################
//
// FILE:	F280x_ADCcalibrationInitAdc.c
//
// TITLE:	Initialize ADC for ADC Calibration Driver Program.
//
//###########################################################################
//
// Ver  | dd-mmm-yyyy |  Who  | Description of changes
// =====|=============|=======|==============================================
//  1.0 | 07 Feb 20056|  MP  | Original Release.
//
//###########################################################################


#include "DSP280x_Device.h"
#include "F280x_ADCcalibrationDriver.h"

extern void DSP28x_usDelay(unsigned long Count);
//extern void ADCOfftrimInit(void);

#define ADC_usDELAY  5000L
#define ADC_usDELAY2  20L


void ADCcalibrationInitAdc(void)
{
	//----------------------------------------------------------------------
    // To powerup the ADC the ADCENCLK bit should be set first to enable
    // clocks handled in InitSysCtrl(), followed by powering up the bandgap and reference circuitry.
    // After a 5ms delay the ADC can be used. 
	//
	
	AdcRegs.ADCTRL3.bit.ADCBGRFDN = 0x3;	// Power up bandgap/reference circuitry
	AdcRegs.ADCTRL3.bit.ADCPWDN = 1;		// Power up rest of ADC
	DSP28x_usDelay(ADC_usDELAY);                  // Delay after powering up ADC
	AdcRegs.ADCTRL3.bit.ADCCLKPS=2;			// ADCCLK=12.5Mhz
	AdcRegs.ADCTRL1.bit.ACQ_PS=0; 			// Acq Time=1ADC CLK
    ADCOfftrimInit();


	//----------------------------------------------------------------------
	// ADC is configurred for either sequential or simultaneous mode of
	// conversion:
	//
	// SEQUENTIAL:   ADC channels are converted one at a time:
	//               A0->A1->A2->...B0->B1->B2->....
	// 
	// SIMULTANEOUS: ADC channels are converted in pairs:
	//               A0->A1->A2->....
	//               B0  B1  B2
	//
	// The mapping of the ADC channel pins to ADC result registers for
	// sequnetial or simultaneous mode is given below:
	//
	// SEQUENTIAL:   ADC channels are converted one at a time:
	//               A0 -> ADCRESULT0
	//               A1 -> ADCRESULT1
	//               A2 -> ADCRESULT2
	//               A3 -> ADCRESULT3
	//               A4 -> ADCRESULT4
	//               A5 -> ADCRESULT5
	//               A6 -> ADCRESULT6
	//               A7 -> ADCRESULT7
	//               B0 -> ADCRESULT8
	//               B1 -> ADCRESULT9
	//               B2 -> ADCRESULT10
	//               B3 -> ADCRESULT11
	//               B4 -> ADCRESULT12
	//               B5 -> ADCRESULT13
	//               B6 -> ADCRESULT14
	//               B7 -> ADCRESULT15
	// 
	// SIMULTANEOUS: ADC channels are converted in pairs:
	//               A0 -> ADCRESULT0
	//               A1 -> ADCRESULT2
	//               A2 -> ADCRESULT4
	//               A3 -> ADCRESULT6
	//               A4 -> ADCRESULT8
	//               A5 -> ADCRESULT10
	//               A6 -> ADCRESULT12
	//               A7 -> ADCRESULT14
	//               B0 -> ADCRESULT1
	//               B1 -> ADCRESULT3
	//               B2 -> ADCRESULT5
	//               B3 -> ADCRESULT7
	//               B4 -> ADCRESULT9
	//               B5 -> ADCRESULT11
	//               B6 -> ADCRESULT13
	//               B7 -> ADCRESULT15
	//

	#if ADC_SAMPLING_MODE == SIMULTANEOUS 
	AdcRegs.ADCTRL3.bit.SMODE_SEL = 1;
    AdcRegs.ADCMAXCONV.all = 7;       		
	#endif

	#if ADC_SAMPLING_MODE == SEQUENTIAL
	AdcRegs.ADCTRL3.bit.SMODE_SEL = 0;
    AdcRegs.ADCMAXCONV.all = 15;       
    #endif	

    AdcRegs.ADCCHSELSEQ1.all= 0x3210; 
    AdcRegs.ADCCHSELSEQ2.all= 0x7654; 
    AdcRegs.ADCCHSELSEQ3.all= 0xba98; 
    AdcRegs.ADCCHSELSEQ4.all= 0xfedc;
    AdcRegs.ADCTRL1.bit.SEQ_CASC=0x1;

	AdcRegs.ADCTRL2.bit.INT_ENA_SEQ1 = 1;  // Enable SEQ1 interrupt (every EOS)	
}	

//===========================================================================
// No more.
//===========================================================================
