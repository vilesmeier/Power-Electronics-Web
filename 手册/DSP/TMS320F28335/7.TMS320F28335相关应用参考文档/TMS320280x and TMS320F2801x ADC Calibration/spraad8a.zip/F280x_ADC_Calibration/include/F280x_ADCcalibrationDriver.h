//###########################################################################
//
// FILE:	ADCcalibrationDriver.h
//
// TITLE:	ADC Calibration Driver Definitions
//
//###########################################################################
//
// Ver  | dd-mmm-yyyy |  Who  | Description of changes
// =====|=============|=======|==============================================
//  1.0 | 20 Jun 2003 | AT/SD | Original Release.
//
//###########################################################################
// 

#ifndef 	__ADC_CALIBRATION_DRIVER_H__
#define 	__ADC_CALIBRATION_DRIVER_H__
#define     NULL    0

//--------------------------------------------------------
// User needs to select ADC sampling mode:
//
// SEQUENTIAL:   ADC channels are converted one at a time:
//               A0->A1->A2->...B0->B1->B2->....
// 
// SIMULTANEOUS: ADC channels are converted in pairs:
//               A0->A1->A2->....
//               B0  B1  B2
  
#define     SEQUENTIAL             1
#define     SIMULTANEOUS           0
#define     ADC_SAMPLING_MODE      SEQUENTIAL

//--------------------------------------------------------
// Mapping of ADC channels to result registers:
//
#if ADC_SAMPLING_MODE == SEQUENTIAL
#define     A0       ADCRESULT0
#define     A1       ADCRESULT1
#define     A2       ADCRESULT2
#define     A3       ADCRESULT3
#define     A4       ADCRESULT4
#define     A5       ADCRESULT5
#define     A6       ADCRESULT6
#define     A7       ADCRESULT7
#define     B0       ADCRESULT8
#define     B1       ADCRESULT9
#define     B2       ADCRESULT10
#define     B3       ADCRESULT11
#define     B4       ADCRESULT12
#define     B5       ADCRESULT13
#define     B6       ADCRESULT14
#define     B7       ADCRESULT15
#endif

#if ADC_SAMPLING_MODE == SIMULTANEOUS
#define     A0       ADCRESULT0
#define     A1       ADCRESULT2
#define     A2       ADCRESULT4
#define     A3       ADCRESULT6
#define     A4       ADCRESULT8
#define     A5       ADCRESULT10
#define     A6       ADCRESULT12
#define     A7       ADCRESULT14
#define     B0       ADCRESULT1
#define     B1       ADCRESULT3
#define     B2       ADCRESULT5
#define     B3       ADCRESULT7
#define     B4       ADCRESULT9
#define     B5       ADCRESULT11
#define     B6       ADCRESULT13
#define     B7       ADCRESULT15
#endif

//--------------------------------------------------------
// User needs to select reference channels and ideal values:
//
// For example:  A6 = RefHigh = 1.5V  (1.5*4095/3.0 = 2048 ideal count)
//               A7 = RefLow  = 0V
//
#define     REF_HIGH_CH				A6
#define     REF_LOW_CH				A7
#define     REF_HIGH_IDEAL_COUNT	2048
#define     REF_LOW_IDEAL_COUNT 	0

//--------------------------------------------------------
// Structure used for storing calibration parameters and 
// results:
//
typedef struct { 
	Uint16  *RefHighChAddr;	     // Channel Address of RefHigh		 
	Uint16  *RefLowChAddr;       // Channel Address of RefLow 	
	Uint16  *Ch0Addr;            // Channel 0 Address
	Uint16  Avg_RefHighActualCount;	 // Ideal RefHigh Count (Q4)
	Uint16  Avg_RefLowActualCount;	 // Ideal RefLow  Count (Q4) 	 
	Uint16  RefHighIdealCount;	 // Ideal RefHigh Count (Q0)		 
	Uint16  RefLowIdealCount;	 // Ideal RefLow  Count (Q0)	 
	Uint16  CalGain; 			 // Calibration Gain   (Q12)	 
    Uint16  CalOffset;			 // Calibration Offset (Q0)	 
                                 // Store Calibrated ADC Data (Q0):
                                 // Simultaneous   Sequential
                                 // ============  ============ 
    Uint16  ch0;                 //      A0            A0  
    Uint16  ch1;                 //      B0            A1
    Uint16  ch2;                 //      A1            A2        
    Uint16  ch3;                 //      B1            A3          
    Uint16  ch4;                 //      A2            A4          
    Uint16  ch5;                 //      B2            A5          
    Uint16  ch6;                 //      A3            A6          
    Uint16  ch7;                 //      B3            A7          
    Uint16  ch8;                 //      A4            B0          
    Uint16  ch9;                 //      B4            B1          
    Uint16  ch10;                //      A5            B2          
    Uint16  ch11;                //      B5            B3          
    Uint16  ch12;                //      A6            B4          
    Uint16  ch13;                //      B6            B5          
    Uint16  ch14;                //      A7            B6          
    Uint16  ch15;                //      B7            B7
    Uint16	StatusExtMux;        // Indicates Status Of External Mux For Current Conversion
}ADC_CALIBRATION_DRIVER_VARS;   


void ADCcalibrationDriverUpdate(ADC_CALIBRATION_DRIVER_VARS *);		
void ADCcalibrationDriverInit(ADC_CALIBRATION_DRIVER_VARS *);
void ADCcalibrationDriverUpdateGainOffsetOnly(ADC_CALIBRATION_DRIVER_VARS *);	
void ADCcalibrationDriverUpdateCorrection(ADC_CALIBRATION_DRIVER_VARS *);	


//==========================================================================
// No more.
//==========================================================================
#endif		// __ADC_CALIBRATION_DRIVER_H__
