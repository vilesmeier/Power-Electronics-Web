//###########################################################################
//
// FILE:	F280x_ADCcalibrationDriverInit.c
//
// TITLE:	ADC Calibration Driver Initialization Function.
//
//###########################################################################
//
// Ver  | dd-mmm-yyyy |  Who  | Description of changes
// =====|=============|=======|==============================================
//  1.0 | 07 Feb 2006 |  MP  | Original Release.
//
//
// Constants listed below are contained in the F280x_ADCcalibrationDriver.h file
//
//
//###########################################################################
 
#include <DSP280x_Device.h>
#include <F280x_ADCcalibrationDriver.h>

void ADCcalibrationDriverInit(ADC_CALIBRATION_DRIVER_VARS *v)
{
	
    
    //----------------------------------------------------------------------
	// Initialize structure variables:
	//
    v->RefHighChAddr     = (void *) &AdcMirror.REF_HIGH_CH; 
    v->RefLowChAddr      = (void *) &AdcMirror.REF_LOW_CH;  
    v->Ch0Addr           = (void *) &AdcMirror.ADCRESULT0;
    v->RefHighIdealCount = REF_HIGH_IDEAL_COUNT;          
    v->RefLowIdealCount  = REF_LOW_IDEAL_COUNT;                 
    v->Avg_RefLowActualCount  = 0;
    v->Avg_RefHighActualCount = 0;
    v->CalGain   = 0; 
    v->CalOffset = 0;
    v->ch0  = 0;
    v->ch1  = 0;
    v->ch2  = 0;
    v->ch3  = 0;
    v->ch4  = 0;
    v->ch5  = 0;
    v->ch6  = 0;
    v->ch7  = 0;
    v->ch8  = 0;
    v->ch9  = 0;
    v->ch10 = 0;
    v->ch11 = 0;
    v->ch12 = 0;
    v->ch13 = 0;
    v->ch14 = 0;
    v->ch15 = 0;  
    
    //----------------------------------------------------------------------
	// Start ADC:
	//
	AdcRegs.ADCTRL2.bit.SOC_SEQ1=1;
	
    //----------------------------------------------------------------------
	// Wait for ADC to finish conversions (test INT1 flag):
	//
    while (AdcRegs.ADCST.bit.INT_SEQ1== 0){}
	AdcRegs.ADCST.bit.INT_SEQ1_CLR = 1;
	
    //----------------------------------------------------------------------
	// Pre-initialize ADC reference values:
	// 
	v->Avg_RefHighActualCount=*(v->RefHighChAddr);
	v->Avg_RefLowActualCount=*(v->RefLowChAddr);	
}

//==========================================================================
// No more.
//==========================================================================
