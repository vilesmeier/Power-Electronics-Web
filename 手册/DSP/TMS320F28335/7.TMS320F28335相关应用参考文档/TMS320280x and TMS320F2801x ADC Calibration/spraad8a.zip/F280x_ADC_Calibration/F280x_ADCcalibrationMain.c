//###########################################################################
//
// FILE:	F280x_ADCcalibrationMain.c
//
// TITLE:	ADC Calibration - Example Program
// 
//###########################################################################
//
// Ver  | dd-mmm-yyyy |  Who  | Description of changes
// =====|=============|=======|==============================================
//  1.0 | 07 Feb 2006 |  MP  | Original Release.
//
//###########################################################################
//
//                            DESCRIPTION
//
// This example program runs from RAM on the EzDSP. It initializes the 
// event manager to generate a periodic start of conversion (SOC) pulse
// to the ADC. This will trigger a conversion of the ADC and when completed
// the ADC will generate an interrupt. The interrupt is serviced and 
// the ADC calibration function is called. This function will read two
// user selected reference channels and calculate the appropriate 
// calibration gain and offset and then calibrate all other user channels.
//
// The program supports configuring the ADC for simultaneous or sequential
// conversion modes:
//
//     SEQUENTIAL:   ADC channels are converted one at a time:
//                   A0->A1->A2->...B0->B1->B2->....
// 
//     SIMULTANEOUS: ADC channels are converted in pairs:
//                   A0->A1->A2->....
//                   B0  B1  B2
//
// The calibrated and converted channels are stored in a RAM structure
// which contains the following information:
//
//    typedef struct { 
//        Uint16  *RefHighChAddr;      // Channel Address of RefHigh		 
//        Uint16  *RefLowChAddr;       // Channel Address of RefLow 	
//        Uint16  *Ch0Addr;            // Channel 0 Address
//        Uint16  Avg_RefHighActualCount; // Ideal RefHigh Count (Q4)
//        Uint16  Avg_RefLowActualCount;  // Ideal RefLow  Count (Q4) 	 
//        Uint16  RefHighIdealCount;   // Ideal RefHigh Count (Q0)		 
//        Uint16  RefLowIdealCount;    // Ideal RefLow  Count (Q0)	 
//        Uint16  CalGain;             // Calibration Gain   (Q12)	 
//        Uint16  CalOffset;           // Calibration Offset (Q0)	 
//                                     // Store Calibrated ADC Data (Q0):
//                                     // Simultaneous   Sequential
//                                     // ============  ============ 
//        Uint16  ch0;                 //      A0            A0  
//        Uint16  ch1;                 //      B0            A1
//        Uint16  ch2;                 //      A1            A2        
//        Uint16  ch3;                 //      B1            A3          
//        Uint16  ch4;                 //      A2            A4          
//        Uint16  ch5;                 //      B2            A5          
//        Uint16  ch6;                 //      A3            A6          
//        Uint16  ch7;                 //      B3            A7          
//        Uint16  ch8;                 //      A4            B0          
//        Uint16  ch9;                 //      B4            B1          
//        Uint16  ch10;                //      A5            B2          
//        Uint16  ch11;                //      B5            B3          
//        Uint16  ch12;                //      A6            B4          
//        Uint16  ch13;                //      B6            B5          
//        Uint16  ch14;                //      A7            B6          
//        Uint16  ch15;                //      B7            B7
//        Uint16  StatusExtMux;        // Status Of External Mux
//    }ADC_CALIBRATION_DRIVER_VARS;   
//
// This program also supports the user toggling a GPIO pin for toggling
// an external analog mux to expand the usable channels.
//
// To adapt to the user system needs, the user needs to configure 
// assembly time switches and settings contained in the header file:
//
//          ADCcalibrationDriver.h
//
// The user needs to select simultaneous or sequential sampling mode 
// of operation. For example:
//                          
//     #define     SEQUENTIAL             1
//     #define     SIMULTANEOUS           0
//     #define     ADC_SAMPLING_MODE      SIMULTANEOUS
//
// And needs to select which ADC channels are connected to reference high
// and reference low and the ideal count value. For example:
//
//     A6 = RefHigh = 1.5V  (1.5*4095/3.0 = 2048 ideal count)
//     A7 = RefLow  = 0V    (0 ideal count)
//
//     #define     REF_HIGH_CH            A6
//     #define     REF_LOW_CH             A7
//     #define     REF_HIGH_IDEAL_COUNT   2048
//     #define     REF_LOW_IDEAL_COUNT    0
//
//###########################################################################

#include <DSP280x_Device.h>
#include <F280x_ADCcalibrationDriver.h>

// Initialize frequency parameters for this program:
//
#define CPU_FREQ 	100E6
#define PWM_FREQ 	250E3
#define PWM_PRD 	CPU_FREQ/PWM_FREQ

// Prototype statements for functions found within this file:
//
interrupt void ADC_ISR(void);


// Allocate calibration driver variables:
//
ADC_CALIBRATION_DRIVER_VARS adc;

//==========================================================================
// MAIN:
//==========================================================================
//
void main(void) 
{

// Step 1. Initialize System Control registers, PLL, WatchDog: 
//           
   InitSysCtrl();

// Step2.  Initialize PIE module:
//
    InitPieCtrl();
	IER = 0x0000;
    IFR = 0x0000;
//	InitPieVectTable();
	PieCtrlRegs.PIECTRL.bit.ENPIE = 1;
    EALLOW;                             // Enable access to protected registers
    PieVectTable.SEQ1INT = &ADC_ISR;
    EDIS;                               // Disable access to protected registers


// Step 3. Initialize ADC and trim offset:
//
    ADCcalibrationInitAdc();
    

// Step 4. Initialize Calibration Driver Variables:

    ADCcalibrationDriverInit(&adc);

   
// Step 5. Initialize GPIO for toggling external Mux (optional):

	EALLOW;
	GpioCtrlRegs.GPBMUX1.bit.GPIO32 = 0;
	GpioCtrlRegs.GPBDIR.bit.GPIO32 = 1;
	EDIS;
	GpioDataRegs.GPBSET.bit.GPIO32 = 1;
	 
// Step 6: Enable core interrupts:
    
	AdcRegs.ADCTRL2.bit.INT_ENA_SEQ1 = 1;
	IER |= M_INT1;		// ADC Interrupt

// Step 7: Enable global interrupts and real-time mode:
//
	EINT;   // Enable Global interrupt INTM
	ERTM;	// Enable Global realtime interrupt DBGM    
	
    PieCtrlRegs.PIEIER1.bit.INTx1 = 1;
	PieCtrlRegs.PIECTRL.bit.ENPIE = 1;
	
// Loop for ever...
    
    AdcRegs.ADCTRL2.bit.SOC_SEQ1 = 1;
	
    while (1) {};						
}

//==========================================================================
// ADC Interrupt Service Routine:
//==========================================================================
// This ISR will be called for all ADC conversions:
//
interrupt void  ADC_ISR(void)
{
	//---------------------------------------------------------------------
	// Read ADC results, calibrate & store in "adc" memory structure:
	//
	ADCcalibrationDriverUpdate(&adc);            // Benchmark = 109 cycles


//Following 2 function calls can be used to seperate the gain/offset calculation
//from the correction of ADC conversions to speed up the correction.
//Gain/Offset correction can be selectively ran based on environment, and correction
//can be done with stored values

//    ADCcalibrationDriverUpdateGainOffsetOnly(&adc);   //use this to calculate gain and offset

//    ADCcalibrationDriverUpdateCorrection(&adc);    //use this to correct ADC results

	//---------------------------------------------------------------------
	// Switch External Channel Mux (optional):
	// Note: Uses GPIO32 for this example.
	adc.StatusExtMux = GpioDataRegs.GPBDAT.bit.GPIO32;  // Save current state of pin
	GpioDataRegs.GPBTOGGLE.bit.GPIO32 = 1;       // Toggle pin and mux will switch
                                                 // Benchmark = 9 cycles
	//---------------------------------------------------------------------
    // Reinitialize for next ADC sequence:
    //
    AdcRegs.ADCTRL2.bit.RST_SEQ1 = 1;            // Reset SEQ1
    AdcRegs.ADCST.bit.INT_SEQ1_CLR = 1;          // Clear INT SEQ1 bit
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;      // Acknowledge interrupt to PIE
    
   	//---------------------------------------------------------------------
    // User code....
    //
    
    return;
}

//==========================================================================
// No more.
//==========================================================================
