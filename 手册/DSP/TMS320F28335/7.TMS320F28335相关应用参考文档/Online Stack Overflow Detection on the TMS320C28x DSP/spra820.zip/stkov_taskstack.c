/*********************************************************************
* File: stkov_taskstack.c                                            *
* Device: TMS320C28x                                                 *
* Author: David M. Alter, Texas Instruments Inc.                     *
* History:                                                           *
*   May 1, 2003 - Original (D. Alter)                                *
*********************************************************************/
/*********************************************************************
* THIS PROGRAM IS PROVIDED "AS IS".  TI MAKES NO WARRANTIES OR       *
* REPRESENTATIONS, EITHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING   *
* ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A           *
* PARTICULAR PURPOSE, LACK OF VIRUSES, ACCURACY OR COMPLETENESS OF   *
* RESPONSES, RESULTS AND LACK OF NEGLIGENCE.  TI DISCLAIMS ANY       *
* WARRANTY OF TITLE, QUIET ENJOYMENT, QUIET POSSESSION, AND          *
* NON-INFRINGEMENT OF ANY THIRD PARTY INTELLECTUAL PROPERTY RIGHTS   *
* WITH REGARD TO THE PROGRAM OR YOUR USE OF THE PROGRAM.             *
*                                                                    *
* IN NO EVENT SHALL TI BE LIABLE FOR ANY SPECIAL, INCIDENTAL,        *
* CONSEQUENTIAL OR INDIRECT DAMAGES, HOWEVER CAUSED, ON ANY THEORY   *
* OF LIABILITY AND WHETHER OR NOT TI HAS BEEN ADVISED OF THE         *
* POSSIBILITY OF SUCH DAMAGES, ARISING IN ANY WAY OUT OF THIS        *
* AGREEMENT, THE PROGRAM, OR YOUR USE OF THE PROGRAM.  EXCLUDED      *
* DAMAGES INCLUDE, BUT ARE NOT LIMITED TO, COST OF REMOVAL OR        *
* REINSTALLATION, COMPUTER TIME, LABOR COSTS, LOSS OF GOODWILL, LOSS *
* OF PROFITS, LOSS OF SAVINGS, OR LOSS OF USE OR INTERRUPTION OF     *
* BUSINESS.  IN NO EVENT WILL TI'S AGGREGATE LIABILITY UNDER THIS    *
* AGREEMENT OR ARISING OUT OF YOUR USE OF THE PROGRAM EXCEED FIVE    *
* HUNDRED DOLLARS U.S.$500).                                         *
*                                                                    *
* Unless otherwise stated, the Program written and copyrighted by    *
* Texas Instruments is distributed as "freeware".  You may, only     *
* under TI's copyright in the Program, use and modify the Program    *
* without any charge or restriction.  You may distribute to third    *
* parties, provided that you transfer a copy of this license to the  *
* third party and the third party agrees to these terms by its first *
* use of the Program.  You must reproduce the copyright notice and   *
* any other legend of ownership on each copy or partial copy, of the *
* Program.                                                           *
*                                                                    *
* You acknowledge and agree that the Program contains copyrighted    *
* material, trade secrets and other TI proprietary information and   *
* is protected by copyright laws, international copyright treaties,  *
* and trade secret laws, as well as other intellectual property      *
* laws.  To protect TI's rights in the Program, you agree not to     *
* decompile, reverse engineer, disassemble or otherwise translate    *
* any object code versions of the Program to a human-readable form.  *
* You agree that in no event will you alter, remove or destroy any   *
* copyright notice included in the Program.  TI reserves all rights  *
* not specifically granted under this license. Except as             *
* specifically provided herein, nothing in this agreement shall be   *
* construed as conferring by implication, estoppel, or otherwise,    *
* upon you, any license or other right under any TI patents,         *
* copyrights or trade secrets.                                       *
*                                                                    *
* You may not use the Program in non-TI devices.                     *
*********************************************************************/

/*** Include Files ***/
#include <std.h>
#include <tsk.h>

// Choose which watchpoint to use (User configurable)
#define WP 1                                // Valid values are 0 or 1 (Default is 1)

// Address and value definitions for Emulation Watchpoint Registers
#if WP == 0
    #define WP_MASK      (volatile unsigned long *)0x00000848  // WP0 MASK register addr
    #define WP_REF       (volatile unsigned long *)0x0000084A  // WP0 REF register addr
    #define WP_EVT_CNTL  (volatile unsigned  int *)0x0000084E  // WP0 EVT_CNTL register addr
    #define WP_EVT_ID    (volatile unsigned  int *)0x0000084F  // WP0 EVT_ID register addr
    #define EVT_CNTL     0x080A                                // EVT_CNTL value for WP0
#else
    #define WP_MASK      (volatile unsigned long *)0x00000828  // WP1 MASK register addr
    #define WP_REF       (volatile unsigned long *)0x0000082A  // WP1 REF register addr
    #define WP_EVT_CNTL  (volatile unsigned  int *)0x0000082E  // WP1 EVT_CNTL register addr
    #define WP_EVT_ID    (volatile unsigned  int *)0x0000082F  // WP1 EVT_ID register addr
    #define EVT_CNTL     0x081A                                // EVT_CNTL value for WP1
#endif

#define STKOV_MARGIN 45                     // Trigger margin is 45 words
#define STKOV_RANGEMASK 0x0007              // 0x0007 = trigger range is 8 words

/*** Other Definitions ***/
extern cregister volatile unsigned int IER;


/*********************************************************************
* Function: STKOV_createTaskStack()                                  *
* Description: Retrieves a tasks stack start address and length, and *
*   places these into the tasks environment.  This function is       *
*   designed to be the task create hook function in DSP/BIOS.        *
* DSP: TMS320C28x                                                    *
* Include files: std.h, tsk.h                                        *
* Function Prototype:                                                *
*   void STKOV_createTaskStack(TSK_Handle);                          *
* Usage: STKOV_switchTaskStack(task);                                *
* Input Parameters:                                                  *
*   TSK_Handle task = handle to task.                                *
* Return Value: none                                                 *
* Notes:                                                             *
*********************************************************************/
void STKOV_createTaskStack(TSK_Handle task)
{
static TSK_Stat status;
unsigned long addr;                         // Address to set the WP at

// Get the task attributes
    TSK_stat(task, &status);

// Compute the watchpoint start address
    addr = ((unsigned long)status.attrs.stack
           + (unsigned long)status.attrs.stacksize - STKOV_MARGIN)
           & (~STKOV_RANGEMASK);

// Assign 'addr' as the value of the task environment pointer
// Note: the environment pointer is not pointing to 'addr'.  Rather,
// the value of the environment pointer is set equal to 'addr'.
    TSK_setenv(task, (unsigned int *)addr);

// Successful Return

} //end of STKOV_createTaskStack()


/*********************************************************************
* Function: STKOV_initTaskStack()                                    *
* Description: Initialization for the DSP/BIOS task switch hook      *
*   function "STKOV_switchTaskStackOvDetect()".  Run this function   *
*   once in main().                                                  *
* DSP: TMS320C28x                                                    *
* Include files: none                                                *
* Function Prototype: unsigned int STKOV_initTaskStackOvDetect(void);*
* Usage: error = STKOV_initTaskStackOvDetect();                      *
* Input Parameters: none                                             *
* Return Value:                                                      *
*    unsigned int error:                                             *
*      0 = no error                                                  *
*      1 = software failed to gain control of the WP                 *
* Notes:                                                             *
*********************************************************************/
unsigned int STKOV_initTaskStack(void)
{
// Enable EALLOW protected register access
    asm(" EALLOW");

// Attempt to gain control of the watchpoint
    *WP_EVT_CNTL = 0x0001;                  // Write 0x0001 to EVT_CNTL to claim ownership
                                            //   of the watchpoint
    asm(" RPT #1 || NOP");                  // Wait at least 3 cycles for the write to occur

// Confirm that the application owns the watchpoint
    if((*WP_EVT_ID & 0xC000) != 0x4000)     // Software failed to gain control of watchpoint
    {
        asm(" EDIS");                       // Disable EALLOW protected register access
        return(1);                          // Return error code
    }

// Proceed to configure the static portion of the watchpoint
    *WP_MASK = (unsigned long)STKOV_RANGEMASK;  // Watchpoint reference address mask
    IER |= 0x8000;                              // Enable RTOSINT

// Successful Return
    asm(" EDIS");                           // Disable EALLOW protected register access
    return(0);                              // Return with no error

} //end of STKOV_initTaskStack()


/*********************************************************************
* Function: STKOV_switchTaskStack()                                  *
* Description: Configures a hardware watchpoint to trigger an        *
*   RTOSINT on write access at the end of a TSK stack.  This         *
*   function is designed to be the task switch hook function in      *
*   DSP/BIOS.                                                        *
* DSP: TMS320C28x                                                    *
* Include files: std.h, tsk.h                                        *
* Function Prototype:                                                *
*   void STKOV_switchTaskStack(TSK_Handle, TSK_Handle);              *
* Usage: STKOV_switchTaskStack(oldtask, newtask);                    *
* Input Parameters:                                                  *
*   TSK_Handle oldtask = handle to old task.                         *
*   TSK_Handle newtask = handle to new task.                         *
* Return Value: none                                                 *
* Notes:                                                             *
*   1) The function STKOV_initTaskStack() must be run once           *
*      before this function can be run.                              *
*   2) The function STKOV_createTaskStack() must have been used as   *
*      the task create hook function.                                *
*********************************************************************/
void STKOV_switchTaskStack(TSK_Handle oldtask, TSK_Handle newtask)
{
unsigned long addr;                         // Address to set the WP at

// Retrieve 'addr' from the task environment pointer
    addr = (unsigned long)TSK_getenv(newtask);

// Enable EALLOW protected register access
    asm(" EALLOW");

// Disable the already owned watchpoint
    *WP_EVT_CNTL = 0x0001;

// Proceed to configure the dynamic portion of the watchpoint
    *WP_REF = addr | (unsigned long)STKOV_RANGEMASK;  // Watchpoint reference address
                                                      //   (write all masked bits as 1's)

// Enable the watchpoint
    *WP_EVT_CNTL = EVT_CNTL;

// Successful Return
    asm(" EDIS");                           // Disable EALLOW protected register access

} //end of STKOV_switchTaskStack()

// end of file stkov_taskstack.c
