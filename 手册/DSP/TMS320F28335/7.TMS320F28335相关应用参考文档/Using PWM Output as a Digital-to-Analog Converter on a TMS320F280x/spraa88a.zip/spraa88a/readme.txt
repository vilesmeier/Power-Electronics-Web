David M. Alter
Texas Instruments, Inc.
September 09, 2008
----------------------------------

This code accompanies the Texas Instruments application report "Using PWM Output
as a Digital-to-Analog Converter on a TMS320F280x Digital Signal Controller," TI
literature #SPRAA88.  The application report can be downloaded from the TI website
at http://www.ti.com.

Please read and understand the disclaimer contained in the file disclaimer.txt.


------------ END OF FILE -------------------
